Pour lancer le programme, ex�cuter la classe Main.java qui se trouve dans le dossier Projet_algo_2019.

Pour comprendre la hi�rarchisation du code, consulter le diagramme UML qui se trouve dans le fichier Compte_rendu.pdf du m�me dossier.

Au lancement du programme, apparition d'une fen�tre graphique repr�sentant la ville avec des b�timents jusque l� construits.

Pour entrer une nouvelle d�pense, cliquer sur le bouton "Nouvelle Entr�e", remplir toutes les cases n�cessaires puis cliquer sur OK. Cela conduit � l'obtention d'un nouveau b�timent.

Pour voir les pr�visions, cliquer sur "Statistiques". Des courbes apparaissent.

Pour fermer le programme, cliquer sur le bouton "Fermer". Cliquer sur la croix en haut � droite de la fen�tre ne permet pas de fermer le programme.